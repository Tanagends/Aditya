list1=[]
n=int(input("enter the number of elements of the list:"))
for x in range(n):
    num=int(input(f"enter the elements of list{x+1}:"))
    list1.append(num)
print(list1)
