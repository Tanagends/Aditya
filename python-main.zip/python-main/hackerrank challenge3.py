name=input()
num=int(input())
if num==0:
     print("Bye {}".format(name))
elif num==1:
     print("Hello {}".format(name))
