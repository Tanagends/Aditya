n=list(input("enter the list of elements:"))
print(n)
