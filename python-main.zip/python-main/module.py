def add(a,b):
    print("the addition is:",a+b)
def sub(a,b):
    print("the difference is:",a-b)
def mul(a,b):
    print("the product is:",a*b)
