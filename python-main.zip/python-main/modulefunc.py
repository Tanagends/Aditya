import module
module.add(5,5)
module.sub(10,3)
module.mul(5,5)
