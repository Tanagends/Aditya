def maximum(a,b,c):
    if(a>b and a>c):
        print("a is bigger")
    elif(b>a and b>c):
        print("b is bigger")
    elif(c>a and c>b):
        print("c is bigger")
    else:
        print("two or more numbers are equal")
    
maximum(20,20,10)
