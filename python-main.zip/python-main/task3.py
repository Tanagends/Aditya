n=tuple(input("enter the tuple of fruits:").split())
print("the total no of fruits in the tuple are:",len(n))
print("the index of mango is :",n.index('mango'))
