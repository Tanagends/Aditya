n=tuple(input("enter the list of elements:"))
set_n=set(n)
print(set_n)
print(type(set_n))
print(type(n))

