class Point:
    def __init__(self,x,y):
        self.x =x
        self.y =y
pl = Point(1,2)
p2 = Point(3,4)
print(pl +p2)
