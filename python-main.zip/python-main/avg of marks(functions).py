def avg_of_marks(maths,dbms,toc,ase,cpp):
    avg=(maths+dbms+toc+ase+cpp)/5
    print(avg)
maths=int(input("enter the  marks:"))
dbms=int(input("enter the  marks:"))
toc=int(input("enter the  marks:"))
ase=int(input("enter the  marks:"))
cpp=int(input("enter the  marks:"))
avg_of_marks(maths,dbms,toc,ase,cpp)
