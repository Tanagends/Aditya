t=eval(input("enter the elements of the tuple:"))
t=()
print(t)
